var redux = require('redux');

console.log('Starting redux example');
