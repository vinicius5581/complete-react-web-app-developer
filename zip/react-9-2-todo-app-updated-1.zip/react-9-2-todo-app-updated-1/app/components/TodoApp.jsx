var React = require('react');

var TodoApp = React.createClass({
  render: function () {
    return (
      <div>
        TodoApp.jsx
      </div>
    )
  }
});

module.exports = TodoApp;
