import React from 'react';

var ComponentOne = React.createClass({
  render: function () {
    return (
      <div>
        <h3>Component One Using React.createClass</h3>
      </div>
    );
  }
});

export default ComponentOne;
