import React from 'react';

class ComponentTwo extends React.Component {
  render () {
    return (
      <div>
        <h3>Component Two Using React.Component</h3>
      </div>
    );
  }
}

export default ComponentTwo;
