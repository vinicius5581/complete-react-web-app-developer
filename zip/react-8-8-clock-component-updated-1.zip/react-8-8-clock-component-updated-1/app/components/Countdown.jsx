var React = require('react');

var Countdown = React.createClass({
  render: function () {
    return <p>Countdown.jsx</p>;
  }
});

module.exports = Countdown;
